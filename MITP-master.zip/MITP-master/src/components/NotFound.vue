<template>
    <div>
        <h3>No encontrado</h3>
    </div>
</template>