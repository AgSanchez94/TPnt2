<template>
    <div>
        Usuario
        {{ $route.params.id }}
    </div>
</template>