<template>
  <div class="register">
    <h1 class="title">Loguin</h1>
    <form >
      <label class="form-label" for="#email">Email:</label>
      <input
        
        class="form-input"
        type="email"
        id="email"
        required
        placeholder="Email"
      >
      <label class="form-label" for="#password">Password:</label>
      <input
        
        class="form-input"
        type="password"
        id="password"
        placeholder="Password"
      >
      
      <input class="form-submit" type="submit" value="Sign Up">
    </form>
  </div>
</template>
