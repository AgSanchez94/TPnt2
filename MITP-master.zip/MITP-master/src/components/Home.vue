<template>
    <div>
        <div>
            <button type="button" class="btn btn-primary">Primary</button>
        </div>
        
    </div>
</template>

